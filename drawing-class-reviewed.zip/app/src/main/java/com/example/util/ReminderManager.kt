package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

enum class ReminderLanguage(val displayName: String, val nativeName: String) {
    BENGALI("Bengali", "বাংলা"),
    ENGLISH("English", "English"),
    HINDI("Hindi", "हिन्दी"),
    ALL_THREE("All 3 Languages", "বাংলা + English + हिन्दी")
}

object ReminderManager {

    fun generateBengaliMessage(studentName: String, monthName: String, amount: String): String {
        return "নমস্কার।\n$studentName-এর $monthName মাসের টিউশন ফি ₹$amount এখনও বাকি রয়েছে। অনুগ্রহ করে সুবিধামতো সময়ে ফি প্রদান করবেন।\nধন্যবাদ।\nDrawing Class"
    }

    fun generateEnglishMessage(studentName: String, monthName: String, amount: String): String {
        return "Hello,\nThe tuition fee of ₹$amount for $studentName for $monthName is still pending. Kindly make the payment at your convenience.\nThank you.\nDrawing Class"
    }

    fun generateHindiMessage(studentName: String, monthName: String, amount: String): String {
        return "नमस्कार।\n$studentName की $monthName महीने की ट्यूशन फीस ₹$amount अभी बाकी है। कृपया अपनी सुविधा के अनुसार फीस का भुगतान कर दें।\nधन्यवाद।\nDrawing Class"
    }

    fun generateMessage(
        language: ReminderLanguage,
        studentName: String,
        monthName: String,
        amount: String
    ): String {
        return when (language) {
            ReminderLanguage.BENGALI -> generateBengaliMessage(studentName, monthName, amount)
            ReminderLanguage.ENGLISH -> generateEnglishMessage(studentName, monthName, amount)
            ReminderLanguage.HINDI -> generateHindiMessage(studentName, monthName, amount)
            ReminderLanguage.ALL_THREE -> {
                val bn = generateBengaliMessage(studentName, monthName, amount)
                val en = generateEnglishMessage(studentName, monthName, amount)
                val hi = generateHindiMessage(studentName, monthName, amount)
                "$bn\n\n---\n\n$en\n\n---\n\n$hi"
            }
        }
    }

    fun sendViaWhatsApp(context: Context, phoneNumber: String, message: String) {
        val cleanPhone = phoneNumber.replace(Regex("[^0-9]"), "")
        val formattedPhone = if (cleanPhone.length == 10) {
            "91$cleanPhone" // Indian country code prefix
        } else if (cleanPhone.startsWith("0")) {
            "91" + cleanPhone.substring(1)
        } else {
            cleanPhone
        }

        try {
            val url = "https://api.whatsapp.com/send?phone=$formattedPhone&text=" + Uri.encode(message)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to general share intent if WhatsApp is not installed or url fails
            sendViaShareIntent(context, message)
        }
    }

    fun sendViaShareIntent(context: Context, message: String) {
        try {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, message)
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, "Send Fee Reminder")
            shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open sharing apps: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
