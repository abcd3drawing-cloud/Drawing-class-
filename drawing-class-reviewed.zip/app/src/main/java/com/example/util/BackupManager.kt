package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.db.PaymentDao
import com.example.data.db.StudentDao
import com.example.data.model.Payment
import com.example.data.model.Student
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackupManager {

    private const val BACKUP_VERSION = 1

    suspend fun createBackupJson(
        studentDao: StudentDao,
        paymentDao: PaymentDao,
        appSettingsJson: String = "{}"
    ): String {
        val root = JSONObject()
        root.put("version", BACKUP_VERSION)
        root.put("appName", "Drawing Class")
        root.put("exportDate", SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ENGLISH).format(Date()))
        root.put("exportTimestamp", System.currentTimeMillis())

        // Export students
        val students = studentDao.getAllStudentsList()
        val studentsArray = JSONArray()
        for (s in students) {
            val studentObj = JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("parentName", s.parentName)
                put("phone", s.phone)
                put("whatsapp", s.whatsapp)
                put("classDay", s.classDay)
                put("startTime", s.startTime)
                put("endTime", s.endTime)
                put("monthlyFee", s.monthlyFee)
                put("joiningDate", s.joiningDate)
                put("photoUri", s.photoUri ?: "")
                put("notes", s.notes)
                put("isArchived", s.isArchived)
                put("createdAt", s.createdAt)
            }
            studentsArray.put(studentObj)
        }
        root.put("students", studentsArray)

        // Export payments
        val payments = paymentDao.getAllPaymentsList()
        val paymentsArray = JSONArray()
        for (p in payments) {
            val paymentObj = JSONObject().apply {
                put("id", p.id)
                put("studentId", p.studentId)
                put("studentName", p.studentName)
                put("month", p.month)
                put("year", p.year)
                put("amount", p.amount)
                put("paymentDate", p.paymentDate)
                put("paymentTime", p.paymentTime)
                put("classTime", p.classTime)
                put("status", p.status)
                put("paymentMode", p.paymentMode)
                put("notes", p.notes)
                put("receiptNumber", p.receiptNumber)
                put("recordedAt", p.recordedAt)
            }
            paymentsArray.put(paymentObj)
        }
        root.put("payments", paymentsArray)

        // Settings
        root.put("settings", JSONObject(appSettingsJson))

        return root.toString(2)
    }

    suspend fun saveBackupToFile(context: Context, jsonString: String): File {
        val backupDir = File(context.cacheDir, "backups")
        if (!backupDir.exists()) backupDir.mkdirs()

        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
        val fileName = "DrawingClass_Backup_$timeStamp.json"
        val file = File(backupDir, fileName)

        file.writeText(jsonString)
        return file
    }

    fun shareBackupFile(context: Context, backupFile: File) {
        val authority = context.packageName + ".fileprovider"
        val uri: Uri = FileProvider.getUriForFile(context, authority, backupFile)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Drawing Class Backup (${backupFile.name})")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(sendIntent, "Export Drawing Class Backup")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    suspend fun restoreFromJson(
        jsonString: String,
        studentDao: StudentDao,
        paymentDao: PaymentDao
    ): Result<RestoreResult> {
        return runCatching {
            val root = JSONObject(jsonString)
            if (!root.has("students") || !root.has("payments")) {
                throw IllegalArgumentException("Invalid backup file: Missing student or payment records.")
            }

            val studentsArray = root.getJSONArray("students")
            val restoredStudents = mutableListOf<Student>()
            for (i in 0 until studentsArray.length()) {
                val obj = studentsArray.getJSONObject(i)
                val photoUriStr = obj.optString("photoUri", "")
                restoredStudents.add(
                    Student(
                        id = obj.optLong("id", 0),
                        name = obj.getString("name"),
                        parentName = obj.optString("parentName", ""),
                        phone = obj.optString("phone", ""),
                        whatsapp = obj.optString("whatsapp", ""),
                        classDay = obj.optString("classDay", ""),
                        startTime = obj.optString("startTime", ""),
                        endTime = obj.optString("endTime", ""),
                        monthlyFee = obj.getDouble("monthlyFee"),
                        joiningDate = obj.optString("joiningDate", ""),
                        photoUri = if (photoUriStr.isNotBlank()) photoUriStr else null,
                        notes = obj.optString("notes", ""),
                        isArchived = obj.optBoolean("isArchived", false),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }

            val paymentsArray = root.getJSONArray("payments")
            val restoredPayments = mutableListOf<Payment>()
            for (i in 0 until paymentsArray.length()) {
                val obj = paymentsArray.getJSONObject(i)
                restoredPayments.add(
                    Payment(
                        id = obj.optLong("id", 0),
                        studentId = obj.getLong("studentId"),
                        studentName = obj.optString("studentName", "Student"),
                        month = obj.getInt("month"),
                        year = obj.getInt("year"),
                        amount = obj.getDouble("amount"),
                        paymentDate = obj.getString("paymentDate"),
                        paymentTime = obj.optString("paymentTime", "12:00 PM"),
                        classTime = obj.optString("classTime", ""),
                        status = obj.optString("status", "PAID"),
                        paymentMode = obj.optString("paymentMode", "Cash"),
                        notes = obj.optString("notes", ""),
                        receiptNumber = obj.optString("receiptNumber", ""),
                        recordedAt = obj.optLong("recordedAt", System.currentTimeMillis())
                    )
                )
            }

            // Clear and replace atomically
            studentDao.clearAll()
            paymentDao.clearAll()

            studentDao.insertAllStudents(restoredStudents)
            paymentDao.insertAllPayments(restoredPayments)

            RestoreResult(
                studentsCount = restoredStudents.size,
                paymentsCount = restoredPayments.size
            )
        }
    }

    data class RestoreResult(val studentsCount: Int, val paymentsCount: Int)
}
