package com.example.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateTimeUtils {
    private val indianLocale = Locale("en", "IN")
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.ENGLISH)

    val monthNames = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    fun getCurrentDateFormatted(): String {
        return dateFormat.format(Date())
    }

    fun getCurrentTimeFormatted(): String {
        return timeFormat.format(Date()).uppercase()
    }

    fun getCurrentMonth(): Int {
        return Calendar.getInstance().get(Calendar.MONTH) + 1
    }

    fun getCurrentYear(): Int {
        return Calendar.getInstance().get(Calendar.YEAR)
    }

    fun getMonthName(monthNumber: Int): String {
        return if (monthNumber in 1..12) {
            monthNames[monthNumber - 1]
        } else {
            "Month $monthNumber"
        }
    }

    fun formatCurrency(amount: Double): String {
        val formatter = NumberFormat.getNumberInstance(indianLocale)
        formatter.maximumFractionDigits = 0
        formatter.minimumFractionDigits = 0
        return "₹" + formatter.format(amount)
    }

    fun formatCurrencyWithDecimals(amount: Double): String {
        return if (amount % 1.0 == 0.0) {
            formatCurrency(amount)
        } else {
            val formatter = NumberFormat.getNumberInstance(indianLocale)
            formatter.maximumFractionDigits = 2
            formatter.minimumFractionDigits = 2
            "₹" + formatter.format(amount)
        }
    }

    fun generateReceiptNumber(year: Int, month: Int, paymentId: Long): String {
        val monthStr = String.format(Locale.ENGLISH, "%02d", month)
        val idStr = String.format(Locale.ENGLISH, "%03d", paymentId)
        return "DC-$year$monthStr-$idStr"
    }
}
