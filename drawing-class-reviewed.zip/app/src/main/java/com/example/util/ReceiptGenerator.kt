package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Payment
import com.example.data.model.Student
import java.io.File
import java.io.FileOutputStream

object ReceiptGenerator {

    private const val AUTHORITY_SUFFIX = ".fileprovider"

    fun generatePdfReceipt(context: Context, student: Student, payment: Payment): File {
        val pdfDocument = PdfDocument()
        val pageWidth = 400
        val pageHeight = 560
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        drawReceiptContent(canvas, pageWidth.toFloat(), pageHeight.toFloat(), student, payment)

        pdfDocument.finishPage(page)

        val receiptsDir = File(context.cacheDir, "receipts")
        if (!receiptsDir.exists()) receiptsDir.mkdirs()

        val receiptName = "DrawingClass_Receipt_${payment.id}_${payment.year}_${payment.month}.pdf"
        val pdfFile = File(receiptsDir, receiptName)

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return pdfFile
    }

    fun generateImageReceipt(context: Context, student: Student, payment: Payment): File {
        val width = 800
        val height = 1120
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        drawReceiptContent(canvas, width.toFloat(), height.toFloat(), student, payment, scale = 2.0f)

        val receiptsDir = File(context.cacheDir, "receipts")
        if (!receiptsDir.exists()) receiptsDir.mkdirs()

        val imageName = "DrawingClass_Receipt_${payment.id}_${payment.year}_${payment.month}.png"
        val imageFile = File(receiptsDir, imageName)

        FileOutputStream(imageFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }

        return imageFile
    }

    private fun drawReceiptContent(
        canvas: Canvas,
        width: Float,
        height: Float,
        student: Student,
        payment: Payment,
        scale: Float = 1.0f
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Background
        canvas.drawColor(Color.WHITE)

        // Outer Border
        paint.color = Color.parseColor("#1A237E") // Deep Indigo
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f * scale
        val margin = 16f * scale
        canvas.drawRoundRect(
            RectF(margin, margin, width - margin, height - margin),
            12f * scale,
            12f * scale,
            paint
        )

        // Inner subtle border
        paint.color = Color.parseColor("#E0E0E0")
        paint.strokeWidth = 1f * scale
        canvas.drawRoundRect(
            RectF(margin + 6f * scale, margin + 6f * scale, width - margin - 6f * scale, height - margin - 6f * scale),
            8f * scale,
            8f * scale,
            paint
        )

        // Header Background Banner
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#1A237E")
        val headerHeight = 75f * scale
        val headerRect = RectF(margin + 6f * scale, margin + 6f * scale, width - margin - 6f * scale, margin + headerHeight)
        canvas.drawRect(headerRect, paint)

        // Header Text: DRAWING CLASS
        paint.color = Color.WHITE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 20f * scale
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("DRAWING CLASS", width / 2f, margin + 35f * scale, paint)

        // Subtitle: Art & Tuition Center
        paint.textSize = 10f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.color = Color.parseColor("#BBDEFB")
        canvas.drawText("TUITION FEE MANAGEMENT • INDIA", width / 2f, margin + 55f * scale, paint)

        // Title: PAYMENT RECEIPT
        paint.color = Color.parseColor("#283593")
        paint.textSize = 15f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        val titleY = margin + headerHeight + 32f * scale
        canvas.drawText("PAYMENT RECEIPT", width / 2f, titleY, paint)

        // Receipt ID & Date line
        val receiptNumber = if (payment.receiptNumber.isNotBlank()) payment.receiptNumber else DateTimeUtils.generateReceiptNumber(payment.year, payment.month, payment.id)
        paint.color = Color.parseColor("#757575")
        paint.textSize = 10f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Receipt No: $receiptNumber", width / 2f, titleY + 18f * scale, paint)

        // Divider
        paint.color = Color.parseColor("#E0E0E0")
        paint.strokeWidth = 1f * scale
        val dividerY = titleY + 28f * scale
        canvas.drawLine(margin + 20f * scale, dividerY, width - margin - 20f * scale, dividerY, paint)

        // Information Rows
        paint.textAlign = Paint.Align.LEFT
        var currentY = dividerY + 26f * scale
        val leftX = margin + 26f * scale
        val rightX = width - margin - 26f * scale
        val rowSpacing = 26f * scale

        fun drawInfoRow(label: String, value: String, isHighlight: Boolean = false) {
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.parseColor("#555555")
            paint.textSize = 11f * scale
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText(label, leftX, currentY, paint)

            paint.typeface = Typeface.create(Typeface.DEFAULT, if (isHighlight) Typeface.BOLD else Typeface.NORMAL)
            paint.color = if (isHighlight) Color.parseColor("#1A237E") else Color.parseColor("#212121")
            paint.textSize = if (isHighlight) 12f * scale else 11f * scale
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText(value, rightX, currentY, paint)

            currentY += rowSpacing
        }

        drawInfoRow("Student Name:", student.name, isHighlight = true)
        if (student.parentName.isNotBlank()) {
            drawInfoRow("Parent / Guardian:", student.parentName)
        }
        val classTimeDisplay = if (payment.classTime.isNotBlank()) payment.classTime else student.displayClassTime
        drawInfoRow("Class Time:", classTimeDisplay)
        val monthDisplay = "${DateTimeUtils.getMonthName(payment.month)} ${payment.year}"
        drawInfoRow("Tuition Month:", monthDisplay, isHighlight = true)
        drawInfoRow("Payment Mode:", payment.paymentMode)
        drawInfoRow("Payment Date:", payment.paymentDate)
        drawInfoRow("Payment Time:", payment.paymentTime)

        // Fee Amount Box
        currentY += 8f * scale
        paint.color = Color.parseColor("#F5F7FA")
        val amountBoxRect = RectF(leftX, currentY - 14f * scale, rightX, currentY + 36f * scale)
        canvas.drawRoundRect(amountBoxRect, 8f * scale, 8f * scale, paint)
        paint.color = Color.parseColor("#CFD8DC")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f * scale
        canvas.drawRoundRect(amountBoxRect, 8f * scale, 8f * scale, paint)

        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#37474F")
        paint.textSize = 12f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("Total Amount Paid:", leftX + 16f * scale, currentY + 16f * scale, paint)

        paint.color = Color.parseColor("#1B5E20") // Deep Green
        paint.textSize = 16f * scale
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText(DateTimeUtils.formatCurrency(payment.amount), rightX - 16f * scale, currentY + 16f * scale, paint)

        // Green PAID Badge
        currentY += 60f * scale
        paint.color = Color.parseColor("#E8F5E9") // Light Green bg
        val badgeWidth = 110f * scale
        val badgeHeight = 32f * scale
        val badgeLeft = (width - badgeWidth) / 2f
        val badgeRect = RectF(badgeLeft, currentY - 18f * scale, badgeLeft + badgeWidth, currentY + 14f * scale)
        canvas.drawRoundRect(badgeRect, 16f * scale, 16f * scale, paint)

        paint.color = Color.parseColor("#2E7D32") // Emerald border
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * scale
        canvas.drawRoundRect(badgeRect, 16f * scale, 16f * scale, paint)

        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#2E7D32")
        paint.textSize = 13f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("✓ STATUS: PAID", width / 2f, currentY + 3f * scale, paint)

        // Footer Note & Thank You
        val footerY = height - margin - 22f * scale
        paint.color = Color.parseColor("#9E9E9E")
        paint.textSize = 9f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("Thank you for your timely payment!", width / 2f, footerY - 14f * scale, paint)
        canvas.drawText("Generated automatically by Drawing Class App", width / 2f, footerY, paint)
    }

    fun shareFile(context: Context, file: File, mimeType: String, title: String) {
        try {
            val authority = context.packageName + AUTHORITY_SUFFIX
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "Error sharing receipt: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareViaWhatsApp(context: Context, phoneNumber: String, file: File, mimeType: String) {
        val cleanPhone = phoneNumber.replace(Regex("[^0-9]"), "")
        val formattedPhone = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone

        try {
            val authority = context.packageName + AUTHORITY_SUFFIX
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra("jid", "$formattedPhone@s.whatsapp.net")
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // If WhatsApp package is not installed or direct jid failed, fallback to standard share chooser
            shareFile(context, file, mimeType, "Share Receipt")
        }
    }
}
