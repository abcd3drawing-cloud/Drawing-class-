package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Payment
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY recordedAt DESC")
    fun getAllPayments(): Flow<List<Payment>>

    @Query("SELECT * FROM payments ORDER BY recordedAt DESC")
    suspend fun getAllPaymentsList(): List<Payment>

    @Query("SELECT * FROM payments WHERE studentId = :studentId ORDER BY year DESC, month DESC, recordedAt DESC")
    fun getPaymentsForStudent(studentId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE month = :month AND year = :year ORDER BY recordedAt DESC")
    fun getPaymentsForMonth(month: Int, year: Int): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE month = :month AND year = :year")
    suspend fun getPaymentsForMonthList(month: Int, year: Int): List<Payment>

    @Query("SELECT * FROM payments WHERE year = :year ORDER BY month ASC, recordedAt DESC")
    fun getPaymentsForYear(year: Int): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE year = :year")
    suspend fun getPaymentsForYearList(year: Int): List<Payment>

    @Query("SELECT * FROM payments WHERE studentId = :studentId AND month = :month AND year = :year LIMIT 1")
    suspend fun getPaymentForStudentMonth(studentId: Long, month: Int, year: Int): Payment?

    @Query("SELECT * FROM payments WHERE id = :id LIMIT 1")
    suspend fun getPaymentById(id: Long): Payment?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllPayments(payments: List<Payment>)

    @Update
    suspend fun updatePayment(payment: Payment)

    @Delete
    suspend fun deletePayment(payment: Payment)

    @Query("DELETE FROM payments WHERE id = :id")
    suspend fun deletePaymentById(id: Long)

    @Query("DELETE FROM payments WHERE studentId = :studentId")
    suspend fun deletePaymentsForStudent(studentId: Long)

    @Query("DELETE FROM payments")
    suspend fun clearAll()
}
