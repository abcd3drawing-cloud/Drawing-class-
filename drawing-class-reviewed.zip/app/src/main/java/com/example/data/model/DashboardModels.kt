package com.example.data.model

data class DashboardData(
    val month: Int,
    val year: Int,
    val totalStudents: Int = 0,
    val expectedFee: Double = 0.0,
    val collectedFee: Double = 0.0,
    val dueFee: Double = 0.0,
    val paidCount: Int = 0,
    val dueCount: Int = 0
)

data class MonthlySummary(
    val month: Int,
    val year: Int,
    val monthName: String,
    val expectedFee: Double,
    val collectedFee: Double,
    val dueFee: Double,
    val paidCount: Int,
    val dueCount: Int
)

data class YearlySummary(
    val year: Int,
    val monthlySummaries: List<MonthlySummary>,
    val totalExpected: Double,
    val totalCollected: Double,
    val totalDue: Double
)

data class StudentDueInfo(
    val student: Student,
    val dueMonth: Int,
    val dueYear: Int,
    val dueAmount: Double
)

data class StudentMonthStatus(
    val student: Student,
    val isPaid: Boolean,
    val payment: Payment? = null
)
