package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val parentName: String,
    val phone: String,
    val whatsapp: String,
    val classDay: String,
    val startTime: String,
    val endTime: String,
    val monthlyFee: Double,
    val joiningDate: String, // DD/MM/YYYY
    val photoUri: String? = null,
    val notes: String = "",
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val displayClassTime: String
        get() = if (startTime.isNotBlank() && endTime.isNotBlank()) {
            "$classDay $startTime – $endTime"
        } else if (classDay.isNotBlank()) {
            classDay
        } else {
            "Flexible Time"
        }
}
