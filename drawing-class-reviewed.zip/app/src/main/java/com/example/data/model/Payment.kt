package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "payments",
    indices = [
        Index(value = ["studentId"]),
        Index(value = ["month", "year"]),
        Index(value = ["studentId", "month", "year"])
    ]
)
data class Payment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentId: Long,
    val studentName: String,
    val month: Int, // 1 to 12
    val year: Int,
    val amount: Double,
    val paymentDate: String, // DD/MM/YYYY
    val paymentTime: String, // e.g. 01:50 PM
    val classTime: String,   // e.g. Monday 05:00 PM – 07:00 PM
    val status: String = "PAID",
    val paymentMode: String = "Cash", // Cash, UPI, Bank Transfer, Other
    val notes: String = "",
    val receiptNumber: String = "",
    val recordedAt: Long = System.currentTimeMillis()
)
