package com.example.data.repository

import com.example.data.db.PaymentDao
import com.example.data.db.StudentDao
import com.example.data.model.DashboardData
import com.example.data.model.MonthlySummary
import com.example.data.model.Payment
import com.example.data.model.Student
import com.example.data.model.StudentDueInfo
import com.example.data.model.StudentMonthStatus
import com.example.data.model.YearlySummary
import com.example.util.DateTimeUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class DrawingClassRepository(
    private val studentDao: StudentDao,
    private val paymentDao: PaymentDao
) {
    val activeStudents: Flow<List<Student>> = studentDao.getActiveStudents()
    val archivedStudents: Flow<List<Student>> = studentDao.getArchivedStudents()
    val allStudents: Flow<List<Student>> = studentDao.getAllStudents()
    val allPayments: Flow<List<Payment>> = paymentDao.getAllPayments()

    fun getStudentById(id: Long): Flow<Student?> = studentDao.getStudentById(id)

    suspend fun getStudentByIdDirect(id: Long): Student? = studentDao.getStudentByIdDirect(id)

    fun getPaymentsForStudent(studentId: Long): Flow<List<Payment>> =
        paymentDao.getPaymentsForStudent(studentId)

    fun getPaymentsForMonth(month: Int, year: Int): Flow<List<Payment>> =
        paymentDao.getPaymentsForMonth(month, year)

    fun getPaymentsForYear(year: Int): Flow<List<Payment>> =
        paymentDao.getPaymentsForYear(year)

    suspend fun insertStudent(student: Student): Long = studentDao.insertStudent(student)

    suspend fun updateStudent(student: Student) = studentDao.updateStudent(student)

    suspend fun setStudentArchived(studentId: Long, archived: Boolean) =
        studentDao.setArchivedStatus(studentId, archived)

    suspend fun deleteStudent(studentId: Long) {
        // Remove dependent payment records first so reports cannot retain orphaned payments.
        paymentDao.deletePaymentsForStudent(studentId)
        studentDao.deleteStudentById(studentId)
    }

    suspend fun recordPayment(payment: Payment): Long = paymentDao.insertPayment(payment)

    suspend fun updatePayment(payment: Payment) = paymentDao.updatePayment(payment)

    suspend fun deletePayment(paymentId: Long) = paymentDao.deletePaymentById(paymentId)

    fun getDashboardData(month: Int, year: Int): Flow<DashboardData> {
        return combine(
            studentDao.getActiveStudents(),
            paymentDao.getPaymentsForMonth(month, year)
        ) { students, payments ->
            val totalStudents = students.size
            val expectedFee = students.sumOf { it.monthlyFee }
            val collectedFee = payments.sumOf { it.amount }
            val paidStudentIds = payments.map { it.studentId }.toSet()
            val paidCount = students.count { paidStudentIds.contains(it.id) }
            val dueCount = (totalStudents - paidCount).coerceAtLeast(0)
            val dueFee = (expectedFee - collectedFee).coerceAtLeast(0.0)

            DashboardData(
                month = month,
                year = year,
                totalStudents = totalStudents,
                expectedFee = expectedFee,
                collectedFee = collectedFee,
                dueFee = dueFee,
                paidCount = paidCount,
                dueCount = dueCount
            )
        }
    }

    fun getDueStudents(month: Int, year: Int): Flow<List<StudentDueInfo>> {
        return combine(
            studentDao.getActiveStudents(),
            paymentDao.getPaymentsForMonth(month, year)
        ) { students, payments ->
            val paidStudentIds = payments.map { it.studentId }.toSet()
            students.filter { !paidStudentIds.contains(it.id) }
                .map { student ->
                    StudentDueInfo(
                        student = student,
                        dueMonth = month,
                        dueYear = year,
                        dueAmount = student.monthlyFee
                    )
                }
        }
    }

    fun getMonthlyOverview(year: Int): Flow<List<MonthlySummary>> {
        return combine(
            studentDao.getActiveStudents(),
            paymentDao.getPaymentsForYear(year)
        ) { students, yearPayments ->
            val paymentsByMonth = yearPayments.groupBy { it.month }
            val expectedFee = students.sumOf { it.monthlyFee }
            val totalStudents = students.size

            (1..12).map { monthNum ->
                val monthPayments = paymentsByMonth[monthNum] ?: emptyList()
                val collected = monthPayments.sumOf { it.amount }
                val paidIds = monthPayments.map { it.studentId }.toSet()
                val paidCount = students.count { paidIds.contains(it.id) }
                val dueCount = (totalStudents - paidCount).coerceAtLeast(0)
                val dueFee = (expectedFee - collected).coerceAtLeast(0.0)

                MonthlySummary(
                    month = monthNum,
                    year = year,
                    monthName = DateTimeUtils.getMonthName(monthNum),
                    expectedFee = expectedFee,
                    collectedFee = collected,
                    dueFee = dueFee,
                    paidCount = paidCount,
                    dueCount = dueCount
                )
            }
        }
    }

    fun getYearlySummary(year: Int): Flow<YearlySummary> {
        return getMonthlyOverview(year).map { monthlyList ->
            val totalExpected = monthlyList.sumOf { it.expectedFee }
            val totalCollected = monthlyList.sumOf { it.collectedFee }
            val totalDue = (totalExpected - totalCollected).coerceAtLeast(0.0)

            YearlySummary(
                year = year,
                monthlySummaries = monthlyList,
                totalExpected = totalExpected,
                totalCollected = totalCollected,
                totalDue = totalDue
            )
        }
    }

    fun getStudentsMonthStatus(month: Int, year: Int): Flow<List<StudentMonthStatus>> {
        return combine(
            studentDao.getActiveStudents(),
            paymentDao.getPaymentsForMonth(month, year)
        ) { students, payments ->
            val paymentMap = payments.associateBy { it.studentId }
            students.map { student ->
                val payment = paymentMap[student.id]
                StudentMonthStatus(
                    student = student,
                    isPaid = payment != null,
                    payment = payment
                )
            }
        }
    }

    val studentDaoRef: StudentDao get() = studentDao
    val paymentDaoRef: PaymentDao get() = paymentDao
}
