package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.Student
import com.example.util.DateTimeUtils
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditStudentScreen(
    studentToEdit: Student? = null,
    onNavigateBack: () -> Unit,
    onSaveStudent: (Student) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current

    var name by remember { mutableStateOf(studentToEdit?.name ?: "") }
    var parentName by remember { mutableStateOf(studentToEdit?.parentName ?: "") }
    var phone by remember { mutableStateOf(studentToEdit?.phone ?: "") }
    var whatsapp by remember { mutableStateOf(studentToEdit?.whatsapp ?: "") }
    var classDay by remember { mutableStateOf(studentToEdit?.classDay ?: "Monday") }
    var startTime by remember { mutableStateOf(studentToEdit?.startTime ?: "05:00 PM") }
    var endTime by remember { mutableStateOf(studentToEdit?.endTime ?: "07:00 PM") }
    var monthlyFeeText by remember { mutableStateOf(studentToEdit?.monthlyFee?.toInt()?.toString() ?: "500") }
    var joiningDate by remember { mutableStateOf(studentToEdit?.joiningDate ?: DateTimeUtils.getCurrentDateFormatted()) }
    var notes by remember { mutableStateOf(studentToEdit?.notes ?: "") }
    var photoUri by remember { mutableStateOf(studentToEdit?.photoUri) }

    var nameError by remember { mutableStateOf(false) }
    var feeError by remember { mutableStateOf(false) }

    val daysOfWeek = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

    // Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                // Copy photo to internal app storage for persistent offline access
                val photosDir = File(context.filesDir, "student_photos")
                if (!photosDir.exists()) photosDir.mkdirs()
                val photoFile = File(photosDir, "student_${System.currentTimeMillis()}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(photoFile).use { output ->
                        input.copyTo(output)
                    }
                }
                photoUri = photoFile.absolutePath
            } catch (e: Exception) {
                photoUri = uri.toString()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (studentToEdit == null) "Add Student" else "Edit Student") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier.fillMaxSize().testTag("add_edit_student_screen")
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Photo Picker Section
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                    .testTag("student_photo_picker"),
                contentAlignment = Alignment.Center
            ) {
                if (!photoUri.isNullOrBlank()) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(photoUri)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Selected Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.CameraAlt,
                            contentDescription = "Add Photo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "Add Photo",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (!photoUri.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Remove Photo",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.clickable { photoUri = null }
                )
            } else {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Student photo (Optional)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Student Name (Required)
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    nameError = it.isBlank()
                },
                label = { Text("Student Name *") },
                isError = nameError,
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().testTag("student_name_input"),
                singleLine = true
            )
            if (nameError) {
                Text(
                    text = "Student name is required",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.align(Alignment.Start)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Parent/Guardian Name
            OutlinedTextField(
                value = parentName,
                onValueChange = { parentName = it },
                label = { Text("Parent / Guardian Name") },
                modifier = Modifier.fillMaxWidth().testTag("parent_name_input"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Phone & WhatsApp
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        phone = it
                        if (whatsapp.isBlank()) whatsapp = it
                    },
                    label = { Text("Phone Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.weight(1f).testTag("phone_input"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedTextField(
                    value = whatsapp,
                    onValueChange = { whatsapp = it },
                    label = { Text("WhatsApp") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.weight(1f).testTag("whatsapp_input"),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Class Day Selector
            Text(
                text = "Class Day",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                daysOfWeek.take(4).forEach { day ->
                    FilterChip(
                        selected = classDay.contains(day),
                        onClick = { classDay = day },
                        label = { Text(day.take(3)) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                daysOfWeek.drop(4).forEach { day ->
                    FilterChip(
                        selected = classDay.contains(day),
                        onClick = { classDay = day },
                        label = { Text(day.take(3)) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Class Start and End Time
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = startTime,
                    onValueChange = { startTime = it },
                    label = { Text("Start Time") },
                    placeholder = { Text("05:00 PM") },
                    modifier = Modifier.weight(1f).testTag("start_time_input"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedTextField(
                    value = endTime,
                    onValueChange = { endTime = it },
                    label = { Text("End Time") },
                    placeholder = { Text("07:00 PM") },
                    modifier = Modifier.weight(1f).testTag("end_time_input"),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Monthly Fee (₹)
            OutlinedTextField(
                value = monthlyFeeText,
                onValueChange = {
                    monthlyFeeText = it
                    feeError = it.toDoubleOrNull() == null || (it.toDoubleOrNull() ?: 0.0) <= 0.0
                },
                label = { Text("Monthly Fee (₹) *") },
                prefix = { Text("₹ ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = feeError,
                modifier = Modifier.fillMaxWidth().testTag("monthly_fee_input"),
                singleLine = true
            )
            if (feeError) {
                Text(
                    text = "Please enter a valid monthly fee",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.align(Alignment.Start)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Joining Date
            OutlinedTextField(
                value = joiningDate,
                onValueChange = { joiningDate = it },
                label = { Text("Joining Date (DD/MM/YYYY)") },
                leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().testTag("joining_date_input"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (Art level, preferred media, etc.)") },
                placeholder = { Text("e.g. Watercolors, Sketching, Beginner") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Save Button
            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = true
                        return@Button
                    }
                    val fee = monthlyFeeText.toDoubleOrNull()
                    if (fee == null || fee <= 0.0) {
                        feeError = true
                        return@Button
                    }

                    val student = Student(
                        id = studentToEdit?.id ?: 0L,
                        name = name.trim(),
                        parentName = parentName.trim(),
                        phone = phone.trim(),
                        whatsapp = whatsapp.trim(),
                        classDay = classDay,
                        startTime = startTime.trim(),
                        endTime = endTime.trim(),
                        monthlyFee = fee,
                        joiningDate = joiningDate.trim(),
                        photoUri = photoUri,
                        notes = notes.trim(),
                        isArchived = studentToEdit?.isArchived ?: false,
                        createdAt = studentToEdit?.createdAt ?: System.currentTimeMillis()
                    )

                    onSaveStudent(student)
                    onNavigateBack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_student_button")
            ) {
                Text(
                    text = if (studentToEdit == null) "+ Save Student" else "Update Student",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
