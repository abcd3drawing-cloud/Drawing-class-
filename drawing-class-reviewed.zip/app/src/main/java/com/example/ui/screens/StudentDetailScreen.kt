package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Payment
import com.example.data.model.Student
import com.example.ui.theme.DueOrange
import com.example.ui.theme.DueOrangeLight
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.PaidGreenLight
import com.example.ui.viewmodel.DrawingClassViewModel
import com.example.util.DateTimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentDetailScreen(
    studentId: Long,
    viewModel: DrawingClassViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToEditStudent: (Student) -> Unit,
    onMarkPayment: (Student) -> Unit,
    onSendReminder: (Student) -> Unit,
    onViewReceipt: (Student, Payment) -> Unit,
    onEditPayment: (Payment) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current

    val studentFlow = remember(studentId) { viewModel.repository.getStudentById(studentId) }
    val student by studentFlow.collectAsStateWithLifecycle(initialValue = null)

    val paymentsFlow = remember(studentId) { viewModel.repository.getPaymentsForStudent(studentId) }
    val studentPayments by paymentsFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()

    var showArchiveDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (student == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Student not found")
        }
        return
    }

    val currentStudent = student!!
    val currentMonthPayment = studentPayments.find { it.month == selectedMonth && it.year == selectedYear }
    val isPaidThisMonth = currentMonthPayment != null

    // Archive Confirmation Dialog
    if (showArchiveDialog) {
        AlertDialog(
            onDismissRequest = { showArchiveDialog = false },
            title = { Text(if (currentStudent.isArchived) "Restore Student?" else "Archive Student?") },
            text = {
                Text(
                    if (currentStudent.isArchived)
                        "Restore ${currentStudent.name} back to the active student list?"
                    else
                        "Archiving ${currentStudent.name} will remove them from the active list, but all their historical payment records will remain safely preserved."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showArchiveDialog = false
                        viewModel.toggleStudentArchive(currentStudent)
                    }
                ) {
                    Text(if (currentStudent.isArchived) "Restore" else "Archive")
                }
            },
            dismissButton = {
                TextButton(onClick = { showArchiveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Permanent Delete Confirmation Dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Student?") },
            text = {
                Text(
                    "Are you sure you want to permanently delete ${currentStudent.name}? It is recommended to Archive instead to preserve fee history."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteDialog = false
                        viewModel.deleteStudentPermanently(currentStudent.id) {
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete Permanently")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Student Profile") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { onNavigateToEditStudent(currentStudent) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Student")
                    }
                    IconButton(onClick = { showArchiveDialog = true }) {
                        Icon(
                            if (currentStudent.isArchived) Icons.Default.Unarchive else Icons.Default.Archive,
                            contentDescription = if (currentStudent.isArchived) "Restore" else "Archive"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier.fillMaxSize().testTag("student_detail_screen")
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Student Profile Header Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        StudentAvatar(
                            photoUri = currentStudent.photoUri,
                            studentName = currentStudent.name,
                            size = 80
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = currentStudent.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        if (currentStudent.parentName.isNotBlank()) {
                            Text(
                                text = "Parent: ${currentStudent.parentName}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Current Month Status Banner
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isPaidThisMonth) PaidGreenLight else DueOrangeLight,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (isPaidThisMonth) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = if (isPaidThisMonth) PaidGreen else DueOrange,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isPaidThisMonth)
                                        "${DateTimeUtils.getMonthName(selectedMonth)} $selectedYear: PAID"
                                    else
                                        "${DateTimeUtils.getMonthName(selectedMonth)} $selectedYear: DUE (₹${currentStudent.monthlyFee.toInt()})",
                                    color = if (isPaidThisMonth) PaidGreen else DueOrange,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            // Quick Primary Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Mark Payment Button
                    Button(
                        onClick = { onMarkPayment(currentStudent) },
                        colors = ButtonDefaults.buttonColors(containerColor = PaidGreen),
                        modifier = Modifier.weight(1f).height(46.dp).testTag("profile_mark_payment_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Mark Payment", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    // Send Fee Reminder Button
                    OutlinedButton(
                        onClick = { onSendReminder(currentStudent) },
                        modifier = Modifier.weight(1f).height(46.dp).testTag("profile_send_reminder_button")
                    ) {
                        Icon(Icons.Default.Notifications, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Send Reminder", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Contact & WhatsApp Quick Actions
            if (currentStudent.phone.isNotBlank() || currentStudent.whatsapp.isNotBlank()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (currentStudent.phone.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${currentStudent.phone}"))
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Call ${currentStudent.phone}")
                            }
                        }

                        val waNumber = if (currentStudent.whatsapp.isNotBlank()) currentStudent.whatsapp else currentStudent.phone
                        if (waNumber.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    val cleanPhone = waNumber.replace(Regex("[^0-9]"), "")
                                    val formatted = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone
                                    val url = "https://api.whatsapp.com/send?phone=$formatted"
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Message, contentDescription = null, modifier = Modifier.size(16.dp), tint = PaidGreen)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("WhatsApp", color = PaidGreen)
                            }
                        }
                    }
                }
            }

            // Student Information Details Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Class & Tuition Details",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(icon = Icons.Default.CurrencyRupee, label = "Monthly Fee", value = DateTimeUtils.formatCurrency(currentStudent.monthlyFee))
                        DetailRow(icon = Icons.Default.Schedule, label = "Class Timing", value = currentStudent.displayClassTime)
                        DetailRow(icon = Icons.Default.CalendarToday, label = "Joining Date", value = currentStudent.joiningDate)
                        if (currentStudent.notes.isNotBlank()) {
                            DetailRow(icon = Icons.Default.Edit, label = "Notes", value = currentStudent.notes)
                        }
                    }
                }
            }

            // Payment History Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Payment History (${studentPayments.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (studentPayments.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = "No payments recorded yet for ${currentStudent.name}.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(studentPayments, key = { it.id }) { payment ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${DateTimeUtils.getMonthName(payment.month)} ${payment.year}",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Paid on ${payment.paymentDate} at ${payment.paymentTime} (${payment.paymentMode})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Text(
                                    text = DateTimeUtils.formatCurrency(payment.amount),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PaidGreen,
                                    fontSize = 16.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Receipt Action
                                OutlinedButton(
                                    onClick = { onViewReceipt(currentStudent, payment) },
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Receipt", style = MaterialTheme.typography.labelSmall)
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                // Edit Payment Action
                                IconButton(
                                    onClick = { onEditPayment(payment) },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = "Edit Payment",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Spacing
            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun DetailRow(
    icon: ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "$label: ",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}
