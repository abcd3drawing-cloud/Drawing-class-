package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

enum class ThemePreset(val title: String, val primaryColorHex: Long) {
    CLASSIC_INDIGO("Classic Indigo", 0xFF1A237E),
    OCEAN_TEAL("Ocean Teal", 0xFF00695C),
    ARTIST_EMERALD("Artist Emerald", 0xFF1B5E20),
    ROYAL_PURPLE("Royal Purple", 0xFF4A148C),
    SUNSET_AMBER("Sunset Amber", 0xFFBF360C)
}

enum class DarkModeSetting(val title: String) {
    SYSTEM("System Default"),
    LIGHT("Light Mode"),
    DARK("Dark Mode")
}

fun getCustomColorScheme(preset: ThemePreset, isDark: Boolean): ColorScheme {
    return when (preset) {
        ThemePreset.CLASSIC_INDIGO -> if (isDark) {
            darkColorScheme(
                primary = IndigoPrimaryDark,
                secondary = IndigoSecondaryDark,
                tertiary = IndigoTertiaryDark,
                background = IndigoBackgroundDark,
                surface = IndigoSurfaceDark,
                onPrimary = Color(0xFF000839),
                onSecondary = Color(0xFF0A1045),
                onBackground = Color(0xFFEDE7F6),
                onSurface = Color(0xFFEDE7F6)
            )
        } else {
            lightColorScheme(
                primary = IndigoPrimaryLight,
                secondary = IndigoSecondaryLight,
                tertiary = IndigoTertiaryLight,
                background = IndigoBackgroundLight,
                surface = IndigoSurfaceLight,
                onPrimary = Color.White,
                onSecondary = Color.White,
                onBackground = Color(0xFF1C1B1F),
                onSurface = Color(0xFF1C1B1F)
            )
        }

        ThemePreset.OCEAN_TEAL -> if (isDark) {
            darkColorScheme(
                primary = TealPrimaryDark,
                secondary = TealSecondaryDark,
                tertiary = TealTertiaryDark,
                background = TealBackgroundDark,
                surface = TealSurfaceDark,
                onPrimary = Color(0xFF00201C),
                onSecondary = Color(0xFF002B25),
                onBackground = Color(0xFFE0F2F1),
                onSurface = Color(0xFFE0F2F1)
            )
        } else {
            lightColorScheme(
                primary = TealPrimaryLight,
                secondary = TealSecondaryLight,
                tertiary = TealTertiaryLight,
                background = TealBackgroundLight,
                surface = TealSurfaceLight,
                onPrimary = Color.White,
                onSecondary = Color.White,
                onBackground = Color(0xFF1C1B1F),
                onSurface = Color(0xFF1C1B1F)
            )
        }

        ThemePreset.ARTIST_EMERALD -> if (isDark) {
            darkColorScheme(
                primary = EmeraldPrimaryDark,
                secondary = EmeraldSecondaryDark,
                tertiary = EmeraldTertiaryDark,
                background = EmeraldBackgroundDark,
                surface = EmeraldSurfaceDark,
                onPrimary = Color(0xFF002106),
                onSecondary = Color(0xFF072B0C),
                onBackground = Color(0xFFE8F5E9),
                onSurface = Color(0xFFE8F5E9)
            )
        } else {
            lightColorScheme(
                primary = EmeraldPrimaryLight,
                secondary = EmeraldSecondaryLight,
                tertiary = EmeraldTertiaryLight,
                background = EmeraldBackgroundLight,
                surface = EmeraldSurfaceLight,
                onPrimary = Color.White,
                onSecondary = Color.White,
                onBackground = Color(0xFF1C1B1F),
                onSurface = Color(0xFF1C1B1F)
            )
        }

        ThemePreset.ROYAL_PURPLE -> if (isDark) {
            darkColorScheme(
                primary = PurplePrimaryDark,
                secondary = PurpleSecondaryDark,
                tertiary = PurpleTertiaryDark,
                background = PurpleBackgroundDark,
                surface = PurpleSurfaceDark,
                onPrimary = Color(0xFF28004F),
                onSecondary = Color(0xFF350466),
                onBackground = Color(0xFFF3E5F5),
                onSurface = Color(0xFFF3E5F5)
            )
        } else {
            lightColorScheme(
                primary = PurplePrimaryLight,
                secondary = PurpleSecondaryLight,
                tertiary = PurpleTertiaryLight,
                background = PurpleBackgroundLight,
                surface = PurpleSurfaceLight,
                onPrimary = Color.White,
                onSecondary = Color.White,
                onBackground = Color(0xFF1C1B1F),
                onSurface = Color(0xFF1C1B1F)
            )
        }

        ThemePreset.SUNSET_AMBER -> if (isDark) {
            darkColorScheme(
                primary = AmberPrimaryDark,
                secondary = AmberSecondaryDark,
                tertiary = AmberTertiaryDark,
                background = AmberBackgroundDark,
                surface = AmberSurfaceDark,
                onPrimary = Color(0xFF3E0A00),
                onSecondary = Color(0xFF4C0E00),
                onBackground = Color(0xFFFBE9E7),
                onSurface = Color(0xFFFBE9E7)
            )
        } else {
            lightColorScheme(
                primary = AmberPrimaryLight,
                secondary = AmberSecondaryLight,
                tertiary = AmberTertiaryLight,
                background = AmberBackgroundLight,
                surface = AmberSurfaceLight,
                onPrimary = Color.White,
                onSecondary = Color.White,
                onBackground = Color(0xFF1C1B1F),
                onSurface = Color(0xFF1C1B1F)
            )
        }
    }
}

@Composable
fun DrawingClassTheme(
    preset: ThemePreset = ThemePreset.CLASSIC_INDIGO,
    darkModeSetting: DarkModeSetting = DarkModeSetting.SYSTEM,
    content: @Composable () -> Unit
) {
    val isSystemDark = isSystemInDarkTheme()
    val isDark = when (darkModeSetting) {
        DarkModeSetting.SYSTEM -> isSystemDark
        DarkModeSetting.LIGHT -> false
        DarkModeSetting.DARK -> true
    }

    val colorScheme = getCustomColorScheme(preset, isDark)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
