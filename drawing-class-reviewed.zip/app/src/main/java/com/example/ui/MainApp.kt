package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.Payment
import com.example.data.model.Student
import com.example.ui.dialogs.EditPaymentDialog
import com.example.ui.dialogs.FeeReminderDialog
import com.example.ui.dialogs.MarkPaymentDialog
import com.example.ui.dialogs.MonthDrillDownDialog
import com.example.ui.dialogs.ReceiptDialog
import com.example.ui.screens.AddEditStudentScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PaymentsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudentDetailScreen
import com.example.ui.screens.StudentsScreen
import com.example.ui.theme.DrawingClassTheme
import com.example.ui.viewmodel.DrawingClassViewModel

sealed class Screen(val route: String) {
    data object Dashboard : Screen("dashboard")
    data object Students : Screen("students")
    data object Payments : Screen("payments")
    data object Reports : Screen("reports")
    data object Settings : Screen("settings")
    data class StudentDetail(val studentId: Long) : Screen("student_detail")
    data class AddEditStudent(val student: Student? = null) : Screen("add_edit_student")
}

data class NavItem(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val screen: Screen,
    val testTag: String
)

@Composable
fun MainApp(
    viewModel: DrawingClassViewModel = viewModel()
) {
    val themePreset by viewModel.themePreset.collectAsStateWithLifecycle()
    val darkModeSetting by viewModel.darkModeSetting.collectAsStateWithLifecycle()

    DrawingClassTheme(
        preset = themePreset,
        darkModeSetting = darkModeSetting
    ) {
        var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }

        // Dialog states
        var markPaymentStudent by remember { mutableStateOf<Student?>(null) }
        var feeReminderStudent by remember { mutableStateOf<Student?>(null) }
        var receiptPair by remember { mutableStateOf<Pair<Student, Payment>?>(null) }
        var editingPayment by remember { mutableStateOf<Payment?>(null) }
        var drillDownInfo by remember { mutableStateOf<Pair<Int, Int>?>(null) }

        val drillDownMonthStatusList by viewModel.drillDownMonthStatusList.collectAsStateWithLifecycle()
        val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
        val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()

        val navItems = listOf(
            NavItem("Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard, Screen.Dashboard, "nav_dashboard"),
            NavItem("Students", Icons.Filled.Group, Icons.Outlined.Group, Screen.Students, "nav_students"),
            NavItem("Payments", Icons.Filled.Payments, Icons.Outlined.Payments, Screen.Payments, "nav_payments"),
            NavItem("Reports", Icons.Filled.DateRange, Icons.Outlined.DateRange, Screen.Reports, "nav_reports"),
            NavItem("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, Screen.Settings, "nav_settings")
        )

        val isMainTab = when (currentScreen) {
            Screen.Dashboard, Screen.Students, Screen.Payments, Screen.Reports, Screen.Settings -> true
            else -> false
        }

        // BackHandler for sub-screens
        if (!isMainTab) {
            BackHandler {
                currentScreen = Screen.Students
            }
        } else if (currentScreen != Screen.Dashboard) {
            BackHandler {
                currentScreen = Screen.Dashboard
            }
        }

        Scaffold(
            bottomBar = {
                if (isMainTab) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 4.dp
                    ) {
                        navItems.forEach { item ->
                            val selected = currentScreen == item.screen
                            NavigationBarItem(
                                icon = {
                                    Icon(
                                        if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.title,
                                        modifier = Modifier.size(24.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        item.title,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                selected = selected,
                                onClick = { currentScreen = item.screen },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (val screen = currentScreen) {
                    Screen.Dashboard -> {
                        DashboardScreen(
                            viewModel = viewModel,
                            onNavigateToAddStudent = { currentScreen = Screen.AddEditStudent(null) },
                            onNavigateToStudents = { currentScreen = Screen.Students },
                            onNavigateToPayments = { currentScreen = Screen.Payments },
                            onMarkPaymentForStudent = { student -> markPaymentStudent = student },
                            onSendReminderForStudent = { student -> feeReminderStudent = student }
                        )
                    }

                    Screen.Students -> {
                        StudentsScreen(
                            viewModel = viewModel,
                            onNavigateToAddStudent = { currentScreen = Screen.AddEditStudent(null) },
                            onSelectStudent = { student -> currentScreen = Screen.StudentDetail(student.id) }
                        )
                    }

                    Screen.Payments -> {
                        PaymentsScreen(
                            viewModel = viewModel,
                            onMarkPaymentForStudent = { student -> markPaymentStudent = student },
                            onSendReminderForStudent = { student -> feeReminderStudent = student },
                            onViewReceipt = { student, payment -> receiptPair = Pair(student, payment) },
                            onEditPayment = { payment -> editingPayment = payment }
                        )
                    }

                    Screen.Reports -> {
                        ReportsScreen(
                            viewModel = viewModel,
                            onMonthTapped = { month, year ->
                                viewModel.setDrillDownMonth(month)
                                drillDownInfo = Pair(month, year)
                            }
                        )
                    }

                    Screen.Settings -> {
                        SettingsScreen(viewModel = viewModel)
                    }

                    is Screen.StudentDetail -> {
                        StudentDetailScreen(
                            studentId = screen.studentId,
                            viewModel = viewModel,
                            onNavigateBack = { currentScreen = Screen.Students },
                            onNavigateToEditStudent = { student -> currentScreen = Screen.AddEditStudent(student) },
                            onMarkPayment = { student -> markPaymentStudent = student },
                            onSendReminder = { student -> feeReminderStudent = student },
                            onViewReceipt = { student, payment -> receiptPair = Pair(student, payment) },
                            onEditPayment = { payment -> editingPayment = payment }
                        )
                    }

                    is Screen.AddEditStudent -> {
                        AddEditStudentScreen(
                            studentToEdit = screen.student,
                            onNavigateBack = {
                                currentScreen = if (screen.student != null) {
                                    Screen.StudentDetail(screen.student.id)
                                } else {
                                    Screen.Students
                                }
                            },
                            onSaveStudent = { student ->
                                viewModel.saveStudent(student) {
                                    currentScreen = Screen.Students
                                }
                            }
                        )
                    }
                }
            }
        }

        // Dialog 1: Mark Payment Dialog
        markPaymentStudent?.let { student ->
            MarkPaymentDialog(
                student = student,
                month = selectedMonth,
                year = selectedYear,
                onDismiss = { markPaymentStudent = null },
                onConfirmPaid = { amount, paymentMode, date, time, notes ->
                    viewModel.markPaymentPaid(
                        student = student,
                        month = selectedMonth,
                        year = selectedYear,
                        amount = amount,
                        paymentMode = paymentMode,
                        notes = notes
                    ) { recordedPayment ->
                        markPaymentStudent = null
                        // Automatically show receipt preview prompt/dialog
                        receiptPair = Pair(student, recordedPayment)
                    }
                }
            )
        }

        // Dialog 2: Fee Reminder Dialog
        feeReminderStudent?.let { student ->
            FeeReminderDialog(
                student = student,
                month = selectedMonth,
                year = selectedYear,
                amount = student.monthlyFee,
                onDismiss = { feeReminderStudent = null }
            )
        }

        // Dialog 3: Payment Receipt Dialog
        receiptPair?.let { (student, payment) ->
            ReceiptDialog(
                student = student,
                payment = payment,
                onDismiss = { receiptPair = null }
            )
        }

        // Dialog 4: Edit Payment Dialog
        editingPayment?.let { payment ->
            EditPaymentDialog(
                payment = payment,
                onDismiss = { editingPayment = null },
                onSavePayment = { updated ->
                    viewModel.updatePaymentRecord(updated) {
                        editingPayment = null
                    }
                },
                onDeletePayment = { paymentId ->
                    viewModel.deletePaymentRecord(paymentId) {
                        editingPayment = null
                    }
                }
            )
        }

        // Dialog 5: Month Drill Down Dialog
        drillDownInfo?.let { (month, year) ->
            MonthDrillDownDialog(
                month = month,
                year = year,
                studentStatusList = drillDownMonthStatusList,
                onDismiss = {
                    drillDownInfo = null
                    viewModel.setDrillDownMonth(null)
                },
                onMarkPaid = { student ->
                    markPaymentStudent = student
                },
                onSendReminder = { student ->
                    feeReminderStudent = student
                },
                onViewReceipt = { student, payment ->
                    receiptPair = Pair(student, payment)
                }
            )
        }
    }
}
