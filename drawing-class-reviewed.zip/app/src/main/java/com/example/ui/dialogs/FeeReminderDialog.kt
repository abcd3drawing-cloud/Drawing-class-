package com.example.ui.dialogs

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Student
import com.example.ui.theme.PaidGreen
import com.example.util.DateTimeUtils
import com.example.util.ReminderLanguage
import com.example.util.ReminderManager

@Composable
fun FeeReminderDialog(
    student: Student,
    month: Int,
    year: Int,
    amount: Double = student.monthlyFee,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedLanguage by remember { mutableStateOf(ReminderLanguage.BENGALI) }
    val monthName = "${DateTimeUtils.getMonthName(month)} $year"
    val formattedAmount = (amount.toInt()).toString()

    var messageText by remember {
        mutableStateOf(
            ReminderManager.generateMessage(
                selectedLanguage,
                student.name,
                monthName,
                formattedAmount
            )
        )
    }

    // Update message text whenever language changes
    LaunchedEffect(selectedLanguage) {
        messageText = ReminderManager.generateMessage(
            selectedLanguage,
            student.name,
            monthName,
            formattedAmount
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth().testTag("fee_reminder_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Send Fee Reminder",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "To: ${student.name} (${student.parentName})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Language Selector Title
                Text(
                    text = "Select Reminder Language",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Language options: বাংলা, English, हिन्दी, Show All 3 Languages
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedLanguage == ReminderLanguage.BENGALI,
                        onClick = { selectedLanguage = ReminderLanguage.BENGALI },
                        label = { Text("বাংলা") },
                        modifier = Modifier.testTag("lang_bengali")
                    )
                    FilterChip(
                        selected = selectedLanguage == ReminderLanguage.ENGLISH,
                        onClick = { selectedLanguage = ReminderLanguage.ENGLISH },
                        label = { Text("English") },
                        modifier = Modifier.testTag("lang_english")
                    )
                    FilterChip(
                        selected = selectedLanguage == ReminderLanguage.HINDI,
                        onClick = { selectedLanguage = ReminderLanguage.HINDI },
                        label = { Text("हिन्दी") },
                        modifier = Modifier.testTag("lang_hindi")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                FilterChip(
                    selected = selectedLanguage == ReminderLanguage.ALL_THREE,
                    onClick = { selectedLanguage = ReminderLanguage.ALL_THREE },
                    label = { Text("Show All 3 Languages (বাংলা + English + हिन्दी)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("lang_all_three")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Editable Message Box
                Text(
                    text = "Message Preview (You can edit before sending)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .testTag("reminder_message_input"),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // WhatsApp info
                val targetPhone = if (student.whatsapp.isNotBlank()) student.whatsapp else student.phone
                if (targetPhone.isNotBlank()) {
                    Text(
                        text = "Recipient Contact: $targetPhone",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    Text(
                        text = "No phone number saved for student",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Send via WhatsApp Button
                    Button(
                        onClick = {
                            if (targetPhone.isNotBlank()) {
                                ReminderManager.sendViaWhatsApp(context, targetPhone, messageText)
                            } else {
                                ReminderManager.sendViaShareIntent(context, messageText)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PaidGreen),
                        modifier = Modifier.fillMaxWidth().testTag("send_whatsapp_button")
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send via WhatsApp", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // General Share Button
                        OutlinedButton(
                            onClick = {
                                ReminderManager.sendViaShareIntent(context, messageText)
                            },
                            modifier = Modifier.weight(1f).testTag("share_reminder_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share")
                        }

                        // Copy Text Button
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Fee Reminder", messageText)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Reminder copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f).testTag("copy_reminder_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy")
                        }
                    }
                }
            }
        }
    }
}
