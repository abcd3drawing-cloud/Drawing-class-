package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.DashboardData
import com.example.data.model.MonthlySummary
import com.example.data.model.Payment
import com.example.data.model.Student
import com.example.data.model.StudentDueInfo
import com.example.data.model.StudentMonthStatus
import com.example.data.model.YearlySummary
import com.example.data.repository.DrawingClassRepository
import com.example.ui.theme.DarkModeSetting
import com.example.ui.theme.ThemePreset
import com.example.util.BackupManager
import com.example.util.DateTimeUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DrawingClassViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    val repository = DrawingClassRepository(database.studentDao(), database.paymentDao())

    // Month & Year state
    val selectedMonth = MutableStateFlow(DateTimeUtils.getCurrentMonth())
    val selectedYear = MutableStateFlow(DateTimeUtils.getCurrentYear())

    // Theme & Settings
    val themePreset = MutableStateFlow(ThemePreset.CLASSIC_INDIGO)
    val darkModeSetting = MutableStateFlow(DarkModeSetting.SYSTEM)

    // Student Filter & Search
    val studentSearchQuery = MutableStateFlow("")
    val studentFilterArchived = MutableStateFlow(false) // false = Active, true = Archived

    // Dashboard Data
    val dashboardData: StateFlow<DashboardData> = combine(
        selectedMonth,
        selectedYear
    ) { month, year -> Pair(month, year) }
        .flatMapLatest { (month, year) ->
            repository.getDashboardData(month, year)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = DashboardData(DateTimeUtils.getCurrentMonth(), DateTimeUtils.getCurrentYear())
        )

    // Due Students for selected month/year
    val dueStudents: StateFlow<List<StudentDueInfo>> = combine(
        selectedMonth,
        selectedYear
    ) { month, year -> Pair(month, year) }
        .flatMapLatest { (month, year) ->
            repository.getDueStudents(month, year)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered Students List
    val studentsList: StateFlow<List<Student>> = combine(
        repository.allStudents,
        studentSearchQuery,
        studentFilterArchived
    ) { allStudents, query, showArchived ->
        allStudents.filter { s ->
            val matchesArchive = if (showArchived) s.isArchived else !s.isArchived
            val matchesSearch = query.isBlank() ||
                    s.name.contains(query, ignoreCase = true) ||
                    s.parentName.contains(query, ignoreCase = true) ||
                    s.phone.contains(query, ignoreCase = true) ||
                    s.whatsapp.contains(query, ignoreCase = true)
            matchesArchive && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // All payments
    val allPayments: StateFlow<List<Payment>> = repository.allPayments.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Monthly Overview for selected year
    val monthlyOverview: StateFlow<List<MonthlySummary>> = selectedYear.flatMapLatest { year ->
        repository.getMonthlyOverview(year)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Yearly Summary for selected year
    val yearlySummary: StateFlow<YearlySummary?> = selectedYear.flatMapLatest { year ->
        repository.getYearlySummary(year)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // Detailed month breakdown for drilled down month in Reports
    val drillDownMonth = MutableStateFlow<Int?>(null)
    val drillDownMonthStatusList: StateFlow<List<StudentMonthStatus>> = combine(
        drillDownMonth,
        selectedYear
    ) { month, year -> if (month != null) Pair(month, year) else null }
        .flatMapLatest { pair ->
            if (pair != null) {
                repository.getStudentsMonthStatus(pair.first, pair.second)
            } else {
                MutableStateFlow(emptyList())
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Actions
    fun setMonth(month: Int) {
        selectedMonth.value = month
    }

    fun setYear(year: Int) {
        selectedYear.value = year
    }

    fun setThemePreset(preset: ThemePreset) {
        themePreset.value = preset
    }

    fun setDarkModeSetting(setting: DarkModeSetting) {
        darkModeSetting.value = setting
    }

    fun setDrillDownMonth(month: Int?) {
        drillDownMonth.value = month
    }

    fun saveStudent(student: Student, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            if (student.id == 0L) {
                repository.insertStudent(student)
            } else {
                repository.updateStudent(student)
            }
            onComplete()
        }
    }

    fun toggleStudentArchive(student: Student, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.setStudentArchived(student.id, !student.isArchived)
            onComplete()
        }
    }

    fun deleteStudentPermanently(studentId: Long, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteStudent(studentId)
            onComplete()
        }
    }

    fun markPaymentPaid(
        student: Student,
        month: Int = selectedMonth.value,
        year: Int = selectedYear.value,
        amount: Double = student.monthlyFee,
        paymentMode: String = "Cash",
        notes: String = "",
        onComplete: (Payment) -> Unit = {}
    ) {
        viewModelScope.launch {
            val paymentDate = DateTimeUtils.getCurrentDateFormatted()
            val paymentTime = DateTimeUtils.getCurrentTimeFormatted()
            val classTime = student.displayClassTime

            val tempPayment = Payment(
                studentId = student.id,
                studentName = student.name,
                month = month,
                year = year,
                amount = amount,
                paymentDate = paymentDate,
                paymentTime = paymentTime,
                classTime = classTime,
                status = "PAID",
                paymentMode = paymentMode,
                notes = notes,
                receiptNumber = ""
            )

            val id = repository.recordPayment(tempPayment)
            val receiptNumber = DateTimeUtils.generateReceiptNumber(year, month, id)
            val finalPayment = tempPayment.copy(id = id, receiptNumber = receiptNumber)
            repository.updatePayment(finalPayment)

            onComplete(finalPayment)
        }
    }

    fun updatePaymentRecord(payment: Payment, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updatePayment(payment)
            onComplete()
        }
    }

    fun deletePaymentRecord(paymentId: Long, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deletePayment(paymentId)
            onComplete()
        }
    }

    // Backup & Restore
    fun exportBackup(context: Context) {
        viewModelScope.launch {
            try {
                val json = BackupManager.createBackupJson(
                    repository.studentDaoRef,
                    repository.paymentDaoRef
                )
                val file = BackupManager.saveBackupToFile(context, json)
                BackupManager.shareBackupFile(context, file)
            } catch (e: Exception) {
                Toast.makeText(context, "Backup failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun restoreBackup(context: Context, jsonString: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = BackupManager.restoreFromJson(
                jsonString,
                repository.studentDaoRef,
                repository.paymentDaoRef
            )
            result.onSuccess { res ->
                onComplete(true, "Restored ${res.studentsCount} students and ${res.paymentsCount} payment records successfully!")
            }.onFailure { err ->
                onComplete(false, "Restore failed: ${err.message}")
            }
        }
    }
}
