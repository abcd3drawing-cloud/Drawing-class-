package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Semantic Status Colors
val PaidGreen = Color(0xFF2E7D32)
val PaidGreenLight = Color(0xFFE8F5E9)
val PaidGreenDark = Color(0xFF81C784)

val DueRed = Color(0xFFD32F2F)
val DueRedLight = Color(0xFFFFEBEE)
val DueRedDark = Color(0xFFE57373)

val DueOrange = Color(0xFFE65100)
val DueOrangeLight = Color(0xFFFFF3E0)

// Preset 1: Classic Indigo (Default)
val IndigoPrimaryLight = Color(0xFF1A237E)
val IndigoSecondaryLight = Color(0xFF3949AB)
val IndigoTertiaryLight = Color(0xFFF57F17)
val IndigoBackgroundLight = Color(0xFFF8F9FE)
val IndigoSurfaceLight = Color(0xFFFFFFFF)

val IndigoPrimaryDark = Color(0xFF9FA8DA)
val IndigoSecondaryDark = Color(0xFF7986CB)
val IndigoTertiaryDark = Color(0xFFFFD54F)
val IndigoBackgroundDark = Color(0xFF121420)
val IndigoSurfaceDark = Color(0xFF1E2130)

// Preset 2: Ocean Teal
val TealPrimaryLight = Color(0xFF00695C)
val TealSecondaryLight = Color(0xFF00897B)
val TealTertiaryLight = Color(0xFFFF7043)
val TealBackgroundLight = Color(0xFFF4FAF8)
val TealSurfaceLight = Color(0xFFFFFFFF)

val TealPrimaryDark = Color(0xFF80CBC4)
val TealSecondaryDark = Color(0xFF4DB6AC)
val TealTertiaryDark = Color(0xFFFFAB91)
val TealBackgroundDark = Color(0xFF101C1A)
val TealSurfaceDark = Color(0xFF1A2C29)

// Preset 3: Artist Emerald
val EmeraldPrimaryLight = Color(0xFF1B5E20)
val EmeraldSecondaryLight = Color(0xFF2E7D32)
val EmeraldTertiaryLight = Color(0xFFFFA000)
val EmeraldBackgroundLight = Color(0xFFF5FBF5)
val EmeraldSurfaceLight = Color(0xFFFFFFFF)

val EmeraldPrimaryDark = Color(0xFFA5D6A7)
val EmeraldSecondaryDark = Color(0xFF81C784)
val EmeraldTertiaryDark = Color(0xFFFFD54F)
val EmeraldBackgroundDark = Color(0xFF121D13)
val EmeraldSurfaceDark = Color(0xFF1E2E20)

// Preset 4: Royal Purple
val PurplePrimaryLight = Color(0xFF4A148C)
val PurpleSecondaryLight = Color(0xFF6A1B9A)
val PurpleTertiaryLight = Color(0xFFD81B60)
val PurpleBackgroundLight = Color(0xFFFAF5FF)
val PurpleSurfaceLight = Color(0xFFFFFFFF)

val PurplePrimaryDark = Color(0xFFCE93D8)
val PurpleSecondaryDark = Color(0xFFBA68C8)
val PurpleTertiaryDark = Color(0xFFF48FB1)
val PurpleBackgroundDark = Color(0xFF191020)
val PurpleSurfaceDark = Color(0xFF271B33)

// Preset 5: Sunset Amber
val AmberPrimaryLight = Color(0xFFBF360C)
val AmberSecondaryLight = Color(0xFFD84315)
val AmberTertiaryLight = Color(0xFF0277BD)
val AmberBackgroundLight = Color(0xFFFFFBF9)
val AmberSurfaceLight = Color(0xFFFFFFFF)

val AmberPrimaryDark = Color(0xFFFFAB91)
val AmberSecondaryDark = Color(0xFFFF8A65)
val AmberTertiaryDark = Color(0xFF81D4FA)
val AmberBackgroundDark = Color(0xFF20130E)
val AmberSurfaceDark = Color(0xFF301E17)
