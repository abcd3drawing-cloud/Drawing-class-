package com.example.ui.dialogs

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Payment
import com.example.data.model.Student
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.PaidGreenLight
import com.example.util.DateTimeUtils
import com.example.util.ReceiptGenerator
import java.io.File

@Composable
fun ReceiptDialog(
    student: Student,
    payment: Payment,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var lastSavedMessage by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 24.dp)
                .testTag("receipt_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Bar with Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Payment Receipt",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // The Visual Receipt Card (matches official format)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, Color(0xFF1A237E), RoundedCornerShape(12.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Header Banner
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF1A237E),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "DRAWING CLASS",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "TUITION FEE RECEIPT • INDIA",
                                    color = Color(0xFFBBDEFB),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "PAYMENT RECEIPT",
                            color = Color(0xFF283593),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        )

                        val receiptNumber = if (payment.receiptNumber.isNotBlank()) {
                            payment.receiptNumber
                        } else {
                            DateTimeUtils.generateReceiptNumber(payment.year, payment.month, payment.id)
                        }

                        Text(
                            text = "Receipt No: $receiptNumber",
                            color = Color(0xFF757575),
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = Color(0xFFEEEEEE), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Receipt Details
                        ReceiptRow(label = "Student:", value = student.name, isBold = true)
                        if (student.parentName.isNotBlank()) {
                            ReceiptRow(label = "Parent / Guardian:", value = student.parentName)
                        }
                        ReceiptRow(
                            label = "Class Time:",
                            value = if (payment.classTime.isNotBlank()) payment.classTime else student.displayClassTime
                        )
                        ReceiptRow(
                            label = "Month:",
                            value = "${DateTimeUtils.getMonthName(payment.month)} ${payment.year}",
                            isBold = true,
                            valueColor = Color(0xFF1A237E)
                        )
                        ReceiptRow(
                            label = "Payment Date:",
                            value = payment.paymentDate
                        )
                        ReceiptRow(
                            label = "Payment Time:",
                            value = payment.paymentTime
                        )
                        ReceiptRow(
                            label = "Payment Mode:",
                            value = payment.paymentMode
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Amount Card
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF5F7FA),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCFD8DC)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Total Amount Paid",
                                    color = Color(0xFF37474F),
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = DateTimeUtils.formatCurrency(payment.amount),
                                    color = Color(0xFF1B5E20),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Green PAID Status Badge
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PaidGreenLight,
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, PaidGreen),
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = PaidGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "STATUS: PAID",
                                    color = PaidGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Thank you for supporting art education!",
                            color = Color(0xFF9E9E9E),
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                if (lastSavedMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = lastSavedMessage ?: "",
                        color = PaidGreen,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Actions Section
                // Primary Action: Share via WhatsApp
                val recipientPhone = if (student.whatsapp.isNotBlank()) student.whatsapp else student.phone
                Button(
                    onClick = {
                        try {
                            val pdfFile = ReceiptGenerator.generatePdfReceipt(context, student, payment)
                            if (recipientPhone.isNotBlank()) {
                                ReceiptGenerator.shareViaWhatsApp(context, recipientPhone, pdfFile, "application/pdf")
                            } else {
                                ReceiptGenerator.shareFile(context, pdfFile, "application/pdf", "Share Payment Receipt")
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PaidGreen),
                    modifier = Modifier.fillMaxWidth().testTag("receipt_whatsapp_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Send to WhatsApp", color = Color.White, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Secondary Action Grid: Generate PDF / Share / Save Image
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // PDF Button
                    OutlinedButton(
                        onClick = {
                            try {
                                val pdfFile = ReceiptGenerator.generatePdfReceipt(context, student, payment)
                                ReceiptGenerator.shareFile(context, pdfFile, "application/pdf", "Share PDF Receipt")
                                lastSavedMessage = "PDF generated: ${pdfFile.name}"
                            } catch (e: Exception) {
                                Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("generate_pdf_button")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFD32F2F))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF", maxLines = 1)
                    }

                    // Image Button
                    OutlinedButton(
                        onClick = {
                            try {
                                val imgFile = ReceiptGenerator.generateImageReceipt(context, student, payment)
                                ReceiptGenerator.shareFile(context, imgFile, "image/png", "Share Receipt Image")
                                lastSavedMessage = "Image saved: ${imgFile.name}"
                            } catch (e: Exception) {
                                Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("save_image_button")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, tint = Color(0xFF1976D2))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Image", maxLines = 1)
                    }

                    // Share button
                    OutlinedButton(
                        onClick = {
                            try {
                                val pdfFile = ReceiptGenerator.generatePdfReceipt(context, student, payment)
                                ReceiptGenerator.shareFile(context, pdfFile, "application/pdf", "Share Receipt")
                            } catch (e: Exception) {
                                Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("share_receipt_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share", maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    valueColor: Color = Color(0xFF212121)
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.5.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = Color(0xFF616161),
            fontSize = 12.sp,
            fontWeight = FontWeight.Normal
        )
        Text(
            text = value,
            color = valueColor,
            fontSize = 12.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium
        )
    }
}
