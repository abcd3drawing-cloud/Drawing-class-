package com.example

import com.example.util.DateTimeUtils
import com.example.util.ReminderLanguage
import com.example.util.ReminderManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DrawingClassLogicTest {

    @Test
    fun testCurrencyFormatting() {
        val formatted = DateTimeUtils.formatCurrency(500.0)
        assertTrue(formatted.contains("₹") && formatted.contains("500"))

        val formattedThousands = DateTimeUtils.formatCurrency(10000.0)
        assertTrue(formattedThousands.contains("₹") && (formattedThousands.contains("10,000") || formattedThousands.contains("10000")))
    }

    @Test
    fun testMonthNames() {
        assertEquals("January", DateTimeUtils.getMonthName(1))
        assertEquals("September", DateTimeUtils.getMonthName(9))
        assertEquals("December", DateTimeUtils.getMonthName(12))
    }

    @Test
    fun testReceiptNumberGeneration() {
        val receiptNumber = DateTimeUtils.generateReceiptNumber(2026, 9, 1)
        assertEquals("DC-202609-001", receiptNumber)
    }

    @Test
    fun testBengaliReminder() {
        val msg = ReminderManager.generateBengaliMessage("Rahul", "September 2026", "500")
        assertTrue(msg.contains("নমস্কার"))
        assertTrue(msg.contains("Rahul"))
        assertTrue(msg.contains("September 2026"))
        assertTrue(msg.contains("500"))
        assertTrue(msg.contains("Drawing Class"))
    }

    @Test
    fun testHindiReminder() {
        val msg = ReminderManager.generateHindiMessage("Rahul", "September 2026", "500")
        assertTrue(msg.contains("नमस्कार"))
        assertTrue(msg.contains("Rahul"))
        assertTrue(msg.contains("September 2026"))
        assertTrue(msg.contains("500"))
        assertTrue(msg.contains("Drawing Class"))
    }

    @Test
    fun testEnglishReminder() {
        val msg = ReminderManager.generateEnglishMessage("Rahul", "September 2026", "500")
        assertTrue(msg.contains("Hello"))
        assertTrue(msg.contains("Rahul"))
        assertTrue(msg.contains("September 2026"))
        assertTrue(msg.contains("₹500"))
        assertTrue(msg.contains("Drawing Class"))
    }

    @Test
    fun testAllThreeLanguagesReminder() {
        val msg = ReminderManager.generateMessage(
            ReminderLanguage.ALL_THREE,
            "Rahul",
            "September 2026",
            "500"
        )
        assertTrue(msg.contains("নমস্কার"))
        assertTrue(msg.contains("नमस्कार"))
        assertTrue(msg.contains("Hello"))
    }
}
